//
//  ViewController.swift
//  calculator
//
//  Created by iMediaLab on 2022/3/28.
//

import UIKit

class ViewController: UIViewController {

    var Values = [Float]()
    var Symbols = [String]()
    var DPoint = false
    var DCount:Int = 0
    var IsNegative = false
    var SignPos:Int = 1
    var operate:Bool = false
    var btn:UIButton! = nil
    var IsAC = false
    var ResetBtn:UIButton! = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Values.append(0)
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var Func: UILabel!
    
    @IBOutlet weak var result: UILabel!
    
    var text_1: String? = ""
    
    @IBAction func sign(_ sender: UIButton) {
        if IsNegative == false {
            Func.text!.insert("-", at: String.Index(utf16Offset: SignPos, in: Func.text!))
            result.text!.insert("-", at: String.Index(utf16Offset: 0, in: result.text!))
            IsNegative = true
        } else {
            Func.text!.remove(at: String.Index(utf16Offset: SignPos, in: Func.text!))
            result.text!.remove(at: String.Index(utf16Offset: 0, in: result.text!))
            IsNegative = false
        }
    }
    
    @IBAction func numbutton(_ sender: UIButton) {
        if sender.configuration?.title != "   0" && sender.configuration?.title != "." {
            text_1 = sender.configuration?.title
            Func.text = Func.text! + text_1!
            switch text_1{
            case "÷", "×", "−", "+":
                if operate == false {
                    if IsNegative == true {
                        Values[Symbols.count] = -Values[Symbols.count]
                        IsNegative = false
                    }
                    Symbols.append(text_1!)
                    Values.append(0)
                    DPoint = false
                    DCount = 0
                    result.text = "0"
                    SignPos = Func.text!.count
                    operate = true
                    if btn != nil {
                        btn.configuration?.background.backgroundColor = .systemPurple
                    }
                    btn = sender
                    btn.configuration?.background.backgroundColor = .systemPink
                } else {
                    Func.text!.remove(at: String.Index(encodedOffset: Func.text!.count - 2))
                    Symbols.removeLast()
                    Symbols.append(text_1!)
                    btn.configuration?.background.backgroundColor = .systemPurple
                    btn = sender
                    btn.configuration?.background.backgroundColor = .systemPink
                }
                break
            case "%":
                Values[Symbols.count] = Values[Symbols.count] / 100
                if floor(Values[Symbols.count]) == Values[Symbols.count] {
                    result.text = String(Int(Values[Symbols.count]))
                } else {
                    result.text = String(Values[Symbols.count])
                }
                operate = false
                break
            default:
                if DPoint == false {
                    Values[Symbols.count] = Values[Symbols.count] * 10 + Float(text_1!)!
                } else {
                    DCount += 1
                    Values[Symbols.count] = Values[Symbols.count] + Float(text_1!)! / pow(10, Float(DCount))
                }
                if floor(Values[Symbols.count]) == Values[Symbols.count] {
                    result.text = String(Int(Values[Symbols.count]))
                } else {
                    result.text = String(Values[Symbols.count])
                }
                operate = false
                break
            }
        } else if sender.configuration?.title == "." {
            if DPoint == false {
                DPoint = true
                Func.text = Func.text! + "."
                result.text = result.text! + "."
            }
            operate = false
        } else {
            Func.text = Func.text! + "0"
            if DPoint == false {
                Values[Symbols.count] = Values[Symbols.count] * 10
                if floor(Values[Symbols.count]) == Values[Symbols.count] {
                    result.text = String(Int(Values[Symbols.count]))
                } else {
                    result.text = String(Values[Symbols.count])
                }
            } else {
                DCount += 1
                result.text = result.text! + "0"
            }
            operate = false
        }
    }
    
    @IBAction func equalbutton(_ sender: UIButton) {
        btn.configuration?.background.backgroundColor = .systemPurple
        btn = sender
        btn.configuration?.background.backgroundColor = .systemPink
        ResetBtn.configuration?.attributedTitle = "AC"
        ResetBtn.configuration?.attributedTitle?.font = UIFont.systemFont(ofSize: 36)
        IsAC = true
        if IsNegative == true {
            Values[Symbols.count] = -Values[Symbols.count]
        }
        Func.text = " "
        Symbols.append("=")
        for j in 0 ..< Symbols.count {
            if floor(Values[j]) == Values[j] {
                Func.text = Func.text! + String(Int(Values[j])) + Symbols[j]
            } else {
                Func.text = Func.text! + String(Values[j]) + Symbols[j]
            }
        }
        Symbols.removeLast()
        var i = 0
        while i != Symbols.count {
            if Symbols[i] == "÷" {
                if Values[i + 1] == 0 {
                    result.text = "0"
                    return
                } else {
                    Values[i] = Values[i] / Values[i + 1]
                    Values.remove(at: i + 1)
                    Symbols.remove(at: i)
                }
            } else {
                i = i + 1
            }
        }
        i = 0
        while i != Symbols.count {
            if Symbols[i] == "×" {
                Values[i] = Values[i] * Values[i + 1]
                Values.remove(at: i + 1)
                Symbols.remove(at: i)
            } else {
                i = i + 1
            }
        }
        while Symbols.count != 0 {
            if Symbols[0] == "−" {
                Values[0] = Values[0] - Values[1]
                Values.remove(at: 1)
                Symbols.remove(at: 0)
            } else {
                Values[0] = Values[0] + Values[1]
                Values.remove(at: 1)
                Symbols.remove(at: 0)
            }
        }
        if floor(Values[0]) == Values[0] {
            result.text = String(Int(Values[0]))
        } else {
            result.text = String(Values[0])
        }
    }
    
    @IBAction func reset(_ sender: UIButton) {
        result.text = "0"
        ResetBtn = sender
        if Values.count > 1 && IsAC == false {
            sender.configuration?.attributedTitle = "AC"
            sender.configuration?.attributedTitle?.font = UIFont.systemFont(ofSize: 36)
            if Values[Values.count - 1] != 0 {
                Values[Values.count - 1] = 0
                Func.text = " "
                for j in 0 ..< (Values.count - 1) {
                    if floor(Values[j]) == Values[j] {
                        Func.text = Func.text! + String(Int(Values[j])) + Symbols[j]
                    } else {
                        Func.text = Func.text! + String(Values[j]) + Symbols[j]
                    }
                }
            }
            IsAC = true
        } else {
            Func.text = " "
            Symbols.removeAll()
            Values.removeAll()
            Values.append(0)
            DPoint = false
            DCount = 0
            IsNegative = false
            SignPos = 1
            sender.configuration?.attributedTitle = "C"
            sender.configuration?.attributedTitle?.font = UIFont.systemFont(ofSize: 36)
            if btn != nil {
                btn.configuration?.background.backgroundColor = .systemPurple
            }
            IsAC = false
        }
    }
    
}

